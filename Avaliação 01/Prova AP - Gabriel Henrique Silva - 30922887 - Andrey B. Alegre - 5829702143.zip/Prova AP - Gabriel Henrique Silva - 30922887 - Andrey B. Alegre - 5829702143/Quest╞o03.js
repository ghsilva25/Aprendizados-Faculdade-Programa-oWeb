let rgm = 87

let x = rgm%2

if(rgm >= 50 && x != 0){

 console.log("RGM ímpar e maior que 50!");

} else if (rgm >= 50 && x == 0) {

    console.log("RGM par e maior que 50!");

} else {
    console.log("RGM menor que 50!");

}