let nome = "Andrey"
let idade = 25
let total = idade + nome.length

for (let i = 1; i <= total; i++){
    console.log(i+" - "+nome)
}