let  Lula = 52
let  Bolsonaro = 50
let  Tebet = 52

if (Bolsonaro > Lula && Bolsonaro > Tebet) {
    console.log("Bolsonaro ganhou no primeiro turno!")
} else if(Lula > Bolsonaro && Lula > Tebet ) {
    console.log("Lula ganhou no primeiro turno!")
}else if (Tebet > Bolsonaro && Tebet > Lula) {
    console.log("Tebet ganhou no primeiro turno!")
}else{
    console.log("Vamos ter segundo turno!")
}

